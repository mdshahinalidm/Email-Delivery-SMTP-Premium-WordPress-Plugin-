<?php

namespace WPMailSMTP\Vendor\Aws\Exception;

/**
 * Class CryptoPolyfillException
 * @package Aws\Exception
 */
class CryptoPolyfillException extends \RuntimeException
{
}
